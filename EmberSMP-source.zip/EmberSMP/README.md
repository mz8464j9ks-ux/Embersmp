# EmberSMP (Paper 1.21.x)
Auction house, player orders, economy (Money + Shards), sell shop, crates + keys,
spawn, /rtp, and a sidebar scoreboard.

## Build the .jar
Requires JDK 21 and Maven, with internet access so Maven can fetch the Paper API:

    mvn clean package

Output: target/EmberSMP.jar. Put it in your server's plugins/ folder and restart.

## Bedrock players (Geyser + Floodgate)
Bedrock players can join a Java Paper server through two free plugins. Put both in plugins/:
1. GeyserMC (Geyser-Spigot works on Paper). It translates the Bedrock protocol.
2. Floodgate. It lets Bedrock players join without a Java account.

Then open plugins/Geyser-Spigot/config.yml and check that:
- `bedrock: port:` is 19132 (the default). Open that port in UDP on your host's firewall.
- `remote: auth-type:` is `floodgate` if your server is in offline mode, or `online` if
  it uses Java accounts. Keep online-mode=true in server.properties unless you know you need offline mode.

Bedrock players connect with the server address and port 19132.
Their Java-side usernames get a "." prefix, which is normal. The plugin works with them as-is.

## Commands
/bal [player]  /pay <player> <amt>  /shards  /sell <hand|all>
/ah  /ah sell <price>  /ah mine
/orders  /orders create <item> <amount> <priceEach>  /orders mine  /orders collect
/rtp  /spawn
Admin (smp.admin): /setspawn, /eco <give|take> <p> <amt>, /shards give <p> <n>,
  /crate <give|set|remove|list|reload>

## Crates
Look at a block, run /crate set common. Give keys with /crate give <player> common 3.
Right-click the block with a key to open it, left-click to preview rewards.
Edit crates.yml, then /crate reload.

## Renaming
config.yml -> names: (money/shards names and symbol), scoreboard.title, scoreboard.footer.
Crate names and rewards are in crates.yml.
