package dev.smp.core;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GuiHolder implements InventoryHolder {
    public enum Type { AH, AH_MINE, ORDERS, ORDERS_MINE }

    public final Type type;
    public final int page;
    /** The listing/order id shown in each slot (index = slot). */
    public final List<UUID> ids = new ArrayList<>();
    private Inventory inventory;

    public GuiHolder(Type type, int page) {
        this.type = type;
        this.page = page;
    }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    @Override
    public @NotNull Inventory getInventory() { return inventory; }
}
