package dev.smp.core;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EconomyManager {
    private final SMPCore plugin;
    private final File file;
    private final Map<UUID, Double> money = new HashMap<>();
    private final Map<UUID, Long> shards = new HashMap<>();

    public EconomyManager(SMPCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "economy.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection m = y.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection s = y.getConfigurationSection("shards");
        if (s != null) for (String k : s.getKeys(false)) shards.put(UUID.fromString(k), s.getLong(k));
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        money.forEach((k, v) -> y.set("money." + k, v));
        shards.forEach((k, v) -> y.set("shards." + k, v));
        try {
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save economy.yml: " + e.getMessage());
        }
    }

    public double getMoney(UUID id) { return money.getOrDefault(id, 0.0); }

    public void addMoney(UUID id, double amt) { money.put(id, getMoney(id) + amt); }

    /** Returns false (and changes nothing) if the player can't afford it. */
    public boolean takeMoney(UUID id, double amt) {
        if (getMoney(id) < amt) return false;
        money.put(id, getMoney(id) - amt);
        return true;
    }

    public long getShards(UUID id) { return shards.getOrDefault(id, 0L); }

    public void addShards(UUID id, long amt) { shards.put(id, Math.max(0, getShards(id) + amt)); }
}
