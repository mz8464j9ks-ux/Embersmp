package dev.smp.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class GuiListener implements Listener {
    private final SMPCore plugin;

    public GuiListener(SMPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof GuiHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof GuiHolder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        int slot = e.getRawSlot();
        if (slot == 45 && h.page > 0) { plugin.gui().open(p, h.type, h.page - 1); return; }
        if (slot == 53 && e.getCurrentItem() != null) { plugin.gui().open(p, h.type, h.page + 1); return; }
        if (slot < 0 || slot >= 45 || slot >= h.ids.size()) return;

        UUID id = h.ids.get(slot);
        switch (h.type) {
            case AH -> buyListing(p, id);
            case AH_MINE -> cancelListing(p, id);
            case ORDERS -> fillOrder(p, id);
            case ORDERS_MINE -> cancelOrder(p, id);
        }
        plugin.gui().open(p, h.type, h.page);
    }

    private void buyListing(Player p, UUID id) {
        AuctionManager.Listing l = plugin.auctions().get(id);
        if (l == null) { Util.msg(p, "&cThat listing is gone."); return; }
        if (l.seller().equals(p.getUniqueId())) { Util.msg(p, "&cYou can't buy your own listing."); return; }
        if (!plugin.economy().takeMoney(p.getUniqueId(), l.price())) {
            Util.msg(p, "&cYou need " + plugin.money(l.price()) + " to buy that.");
            return;
        }
        plugin.auctions().remove(id);
        double tax = l.price() * plugin.getConfig().getDouble("auction.tax-percent", 5) / 100.0;
        double payout = l.price() - tax;
        plugin.economy().addMoney(l.seller(), payout);
        Util.give(p, l.item().clone());
        Util.msg(p, "&aBought item for " + plugin.money(l.price()) + ".");
        Player seller = Bukkit.getPlayer(l.seller());
        if (seller != null) {
            Util.msg(seller, "&a" + p.getName() + " bought your listing! You received " + plugin.money(payout)
                    + " &7(" + plugin.money(tax) + " tax)");
        }
    }

    private void cancelListing(Player p, UUID id) {
        AuctionManager.Listing l = plugin.auctions().get(id);
        if (l == null || !l.seller().equals(p.getUniqueId())) return;
        plugin.auctions().remove(id);
        Util.give(p, l.item().clone());
        Util.msg(p, "&eListing cancelled and item returned.");
    }

    private void fillOrder(Player p, UUID id) {
        OrderManager.Order o = plugin.orders().get(id);
        if (o == null) { Util.msg(p, "&cThat order is gone."); return; }
        if (o.buyer.equals(p.getUniqueId())) { Util.msg(p, "&cYou can't fill your own order."); return; }

        int have = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && it.getType() == o.material && Util.plain(it)) have += it.getAmount();
        }
        int n = Math.min(have, o.remaining);
        if (n <= 0) { Util.msg(p, "&cYou have no plain " + pretty(o.material) + " to sell."); return; }

        int toRemove = n;
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && toRemove > 0; i++) {
            ItemStack it = contents[i];
            if (it == null || it.getType() != o.material || !Util.plain(it)) continue;
            int take = Math.min(toRemove, it.getAmount());
            if (take == it.getAmount()) contents[i] = null;
            else it.setAmount(it.getAmount() - take);
            toRemove -= take;
        }
        p.getInventory().setStorageContents(contents);

        double pay = n * o.priceEach;
        plugin.economy().addMoney(p.getUniqueId(), pay);
        o.remaining -= n;
        plugin.orders().addPending(o.buyer, o.material, n);
        if (o.remaining <= 0) plugin.orders().remove(o.id);

        Util.msg(p, "&aSold " + n + "x " + pretty(o.material) + " for " + plugin.money(pay) + ".");
        Player buyer = Bukkit.getPlayer(o.buyer);
        if (buyer != null) {
            Util.msg(buyer, "&a" + p.getName() + " filled " + n + "x " + pretty(o.material)
                    + " of your order. Use &e/orders collect&a.");
        }
    }

    private void cancelOrder(Player p, UUID id) {
        OrderManager.Order o = plugin.orders().get(id);
        if (o == null || !o.buyer.equals(p.getUniqueId())) return;
        plugin.orders().remove(id);
        double refund = o.remaining * o.priceEach;
        plugin.economy().addMoney(p.getUniqueId(), refund);
        Util.msg(p, "&eOrder cancelled. Refunded " + plugin.money(refund) + ".");
    }

    static String pretty(Material m) {
        return m.name().toLowerCase().replace('_', ' ');
    }
}
