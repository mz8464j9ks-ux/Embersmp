package dev.smp.core;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class OrderManager {
    public static class Order {
        public final UUID id;
        public final UUID buyer;
        public final String buyerName;
        public final Material material;
        public int remaining;
        public final double priceEach;

        public Order(UUID id, UUID buyer, String buyerName, Material material, int remaining, double priceEach) {
            this.id = id;
            this.buyer = buyer;
            this.buyerName = buyerName;
            this.material = material;
            this.remaining = remaining;
            this.priceEach = priceEach;
        }
    }

    private final SMPCore plugin;
    private final File file;
    private final Map<UUID, Order> orders = new LinkedHashMap<>();
    /** Items bought through orders, waiting for the buyer to /orders collect. */
    private final Map<UUID, Map<Material, Integer>> pending = new HashMap<>();

    public OrderManager(SMPCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "orders.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("orders");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(key);
                if (s == null) continue;
                Material mat = Material.matchMaterial(s.getString("material", ""));
                if (mat == null) continue;
                UUID id = UUID.fromString(key);
                orders.put(id, new Order(id, UUID.fromString(s.getString("buyer", "")),
                        s.getString("buyerName", "?"), mat, s.getInt("remaining"), s.getDouble("priceEach")));
            }
        }
        ConfigurationSection pend = y.getConfigurationSection("pending");
        if (pend != null) {
            for (String uuid : pend.getKeys(false)) {
                ConfigurationSection s = pend.getConfigurationSection(uuid);
                if (s == null) continue;
                Map<Material, Integer> m = new EnumMap<>(Material.class);
                for (String mk : s.getKeys(false)) {
                    Material mat = Material.matchMaterial(mk);
                    if (mat != null) m.put(mat, s.getInt(mk));
                }
                pending.put(UUID.fromString(uuid), m);
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Order o : orders.values()) {
            String p = "orders." + o.id + ".";
            y.set(p + "buyer", o.buyer.toString());
            y.set(p + "buyerName", o.buyerName);
            y.set(p + "material", o.material.name());
            y.set(p + "remaining", o.remaining);
            y.set(p + "priceEach", o.priceEach);
        }
        pending.forEach((uuid, m) -> m.forEach((mat, n) -> y.set("pending." + uuid + "." + mat.name(), n)));
        try {
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save orders.yml: " + e.getMessage());
        }
    }

    public Order create(UUID buyer, String name, Material mat, int amount, double priceEach) {
        Order o = new Order(UUID.randomUUID(), buyer, name, mat, amount, priceEach);
        orders.put(o.id, o);
        return o;
    }

    public Order get(UUID id) { return orders.get(id); }

    public Order remove(UUID id) { return orders.remove(id); }

    public List<Order> all() { return new ArrayList<>(orders.values()); }

    public List<Order> byBuyer(UUID buyer) {
        List<Order> out = new ArrayList<>();
        for (Order o : orders.values()) if (o.buyer.equals(buyer)) out.add(o);
        return out;
    }

    public void addPending(UUID buyer, Material mat, int amount) {
        pending.computeIfAbsent(buyer, k -> new EnumMap<>(Material.class)).merge(mat, amount, Integer::sum);
    }

    /** Returns and clears everything waiting for this player. */
    public Map<Material, Integer> takePending(UUID buyer) {
        Map<Material, Integer> m = pending.remove(buyer);
        return m == null ? Map.of() : m;
    }

    public boolean hasPending(UUID buyer) {
        Map<Material, Integer> m = pending.get(buyer);
        return m != null && !m.isEmpty();
    }
}
