package dev.smp.core;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SidebarManager implements Listener {
    private static final int LINES = 10;
    private static final String OBJECTIVE = "smp";

    private final SMPCore plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public SidebarManager(SMPCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long period = Math.max(1, plugin.getConfig().getLong("scoreboard.update-ticks", 20));
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) update(p);
        }, 20L, period);
    }

    /** Each line needs a unique hidden entry. Legacy codes §0..§9 are all distinct. */
    private static String entry(int i) {
        return "\u00A7" + (char) ('0' + i);
    }

    private Component title() {
        return Util.c(plugin.getConfig().getString("scoreboard.title", "&b&l SMP "));
    }

    private Scoreboard boardFor(Player p) {
        return boards.computeIfAbsent(p.getUniqueId(), id -> {
            Scoreboard b = Bukkit.getScoreboardManager().getNewScoreboard();
            Objective o = b.registerNewObjective(OBJECTIVE, Criteria.DUMMY, title());
            o.setDisplaySlot(DisplaySlot.SIDEBAR);
            for (int i = 0; i < LINES; i++) {
                Team t = b.registerNewTeam("line" + i);
                t.addEntry(entry(i));
                o.getScore(entry(i)).setScore(LINES - i);
            }
            return b;
        });
    }

    public void update(Player p) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;

        Scoreboard b = boardFor(p);
        Objective o = b.getObjective(OBJECTIVE);
        if (o != null) o.displayName(title());

        List<String> lines = buildLines(p);
        for (int i = 0; i < LINES; i++) {
            Team t = b.getTeam("line" + i);
            if (t != null) t.prefix(Util.c(i < lines.size() ? lines.get(i) : ""));
        }

        if (p.getScoreboard() != b) p.setScoreboard(b);
    }

    private List<String> buildLines(Player p) {
        var id = p.getUniqueId();
        List<String> l = new ArrayList<>();
        l.add("&8--------------------");
        l.add("&f" + plugin.moneyName() + ": &a" + plugin.money(plugin.economy().getMoney(id)));
        l.add("&f" + plugin.shardsName() + ": &b" + plugin.economy().getShards(id));
        l.add("&7 ");
        l.add("&fListings: &6" + plugin.auctions().bySeller(id).size());
        l.add("&fOrders: &d" + plugin.orders().byBuyer(id).size());
        l.add("&fOnline: &e" + Bukkit.getOnlinePlayers().size());
        l.add("&8 ");
        l.add(plugin.getConfig().getString("scoreboard.footer", "&7/rtp to explore"));
        l.add("&8--------------------");
        return l;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        update(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        boards.remove(e.getPlayer().getUniqueId());
    }
}
