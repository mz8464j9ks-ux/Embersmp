package dev.smp.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class CrateManager {
    public record Reward(double weight, String type, String display, Map<?, ?> data) {}
    public record Crate(String id, String display, List<Reward> rewards) {
        double totalWeight() {
            double t = 0;
            for (Reward r : rewards) t += r.weight();
            return t;
        }
    }

    private final SMPCore plugin;
    private final File crateFile;
    private final File locFile;
    private final NamespacedKey keyTag;
    private final Random random = new Random();
    private final Map<String, Crate> crates = new LinkedHashMap<>();
    /** "world;x;y;z" -> crate id */
    private final Map<String, String> locations = new HashMap<>();

    public CrateManager(SMPCore plugin) {
        this.plugin = plugin;
        this.crateFile = new File(plugin.getDataFolder(), "crates.yml");
        this.locFile = new File(plugin.getDataFolder(), "crate-locations.yml");
        this.keyTag = new NamespacedKey(plugin, "crate_key");
        load();
    }

    public void load() {
        crates.clear();
        locations.clear();

        YamlConfiguration y = YamlConfiguration.loadConfiguration(crateFile);
        ConfigurationSection sec = y.getConfigurationSection("crates");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                String display = sec.getString(id + ".display", id);
                List<Reward> rewards = new ArrayList<>();
                for (Map<?, ?> m : sec.getMapList(id + ".rewards")) {
                    double weight = num(m.get("weight"), 1);
                    String type = String.valueOf(m.get("type"));
                    String disp = m.get("display") == null ? type : String.valueOf(m.get("display"));
                    rewards.add(new Reward(weight, type.toLowerCase(), disp, m));
                }
                crates.put(id.toLowerCase(), new Crate(id.toLowerCase(), display, rewards));
            }
        }

        YamlConfiguration l = YamlConfiguration.loadConfiguration(locFile);
        for (String s : l.getStringList("locations")) {
            int i = s.lastIndexOf(';');
            if (i > 0) locations.put(s.substring(0, i), s.substring(i + 1));
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> out = new ArrayList<>();
        locations.forEach((k, v) -> out.add(k + ";" + v));
        y.set("locations", out);
        try {
            y.save(locFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save crate-locations.yml: " + e.getMessage());
        }
    }

    private static double num(Object o, double def) {
        return o instanceof Number n ? n.doubleValue() : def;
    }

    public Crate get(String id) { return id == null ? null : crates.get(id.toLowerCase()); }

    public Iterable<String> ids() { return crates.keySet(); }

    private static String keyOf(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    public Crate crateAt(Block b) { return get(locations.get(keyOf(b))); }

    public void setCrate(Block b, Crate c) { locations.put(keyOf(b), c.id()); save(); }

    public boolean removeCrate(Block b) {
        boolean removed = locations.remove(keyOf(b)) != null;
        if (removed) save();
        return removed;
    }

    public ItemStack createKey(Crate c, int amount) {
        ItemStack it = new ItemStack(Material.TRIPWIRE_HOOK, amount);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Util.c(c.display() + " &fKey"));
        meta.lore(List.of(Util.c("&7Right-click a " + "crate to open it.")));
        meta.getPersistentDataContainer().set(keyTag, PersistentDataType.STRING, c.id());
        it.setItemMeta(meta);
        return it;
    }

    public boolean isKeyFor(ItemStack it, Crate c) {
        if (it == null || !it.hasItemMeta()) return false;
        String v = it.getItemMeta().getPersistentDataContainer().get(keyTag, PersistentDataType.STRING);
        return c.id().equals(v);
    }

    public Reward roll(Crate c) {
        double r = random.nextDouble() * c.totalWeight();
        for (Reward rw : c.rewards()) {
            r -= rw.weight();
            if (r <= 0) return rw;
        }
        return c.rewards().get(c.rewards().size() - 1);
    }

    public void grant(Player p, Reward r) {
        Map<?, ?> d = r.data();
        switch (r.type()) {
            case "money" -> plugin.economy().addMoney(p.getUniqueId(), num(d.get("amount"), 0));
            case "shards" -> plugin.economy().addShards(p.getUniqueId(), (long) num(d.get("amount"), 0));
            case "item" -> {
                Material m = Material.matchMaterial(String.valueOf(d.get("material")));
                if (m != null) Util.give(p, new ItemStack(m, (int) num(d.get("amount"), 1)));
            }
            case "command" -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    String.valueOf(d.get("command")).replace("%player%", p.getName()));
            default -> plugin.getLogger().warning("Unknown reward type: " + r.type());
        }
    }

    public void open(Player p, Crate c) {
        Reward r = roll(c);
        grant(p, r);
        Util.msg(p, c.display() + " &7» You won: " + r.display());
    }

    public void preview(Player p, Crate c) {
        Util.msg(p, c.display() + " &7rewards:");
        double total = c.totalWeight();
        for (Reward r : c.rewards()) {
            Util.msg(p, " &8- " + r.display() + " &7(" + String.format("%.1f", r.weight() / total * 100) + "%)");
        }
    }
}
