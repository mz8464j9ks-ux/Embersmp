package dev.smp.core;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class AuctionManager {
    public record Listing(UUID id, UUID seller, String sellerName, ItemStack item, double price) {}

    private final SMPCore plugin;
    private final File file;
    private final Map<UUID, Listing> listings = new LinkedHashMap<>();

    public AuctionManager(SMPCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auction.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("listings");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) continue;
            ItemStack item = s.getItemStack("item");
            if (item == null) continue;
            UUID id = UUID.fromString(key);
            listings.put(id, new Listing(id, UUID.fromString(s.getString("seller", "")),
                    s.getString("sellerName", "?"), item, s.getDouble("price")));
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Listing l : listings.values()) {
            String p = "listings." + l.id() + ".";
            y.set(p + "seller", l.seller().toString());
            y.set(p + "sellerName", l.sellerName());
            y.set(p + "price", l.price());
            y.set(p + "item", l.item());
        }
        try {
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save auction.yml: " + e.getMessage());
        }
    }

    public Listing add(UUID seller, String name, ItemStack item, double price) {
        Listing l = new Listing(UUID.randomUUID(), seller, name, item, price);
        listings.put(l.id(), l);
        return l;
    }

    public Listing get(UUID id) { return listings.get(id); }

    public Listing remove(UUID id) { return listings.remove(id); }

    public List<Listing> all() { return new ArrayList<>(listings.values()); }

    public List<Listing> bySeller(UUID seller) {
        List<Listing> out = new ArrayList<>();
        for (Listing l : listings.values()) if (l.seller().equals(seller)) out.add(l);
        return out;
    }
}
