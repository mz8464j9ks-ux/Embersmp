package dev.smp.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.io.File;
import java.io.IOException;

public class SpawnManager implements Listener {
    private final SMPCore plugin;
    private final File file;
    private Location spawn;

    public SpawnManager(SMPCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "spawn.yml");
        load();
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        World w = Bukkit.getWorld(y.getString("world", ""));
        if (w == null) return;
        spawn = new Location(w,
                y.getDouble("x"), y.getDouble("y"), y.getDouble("z"),
                (float) y.getDouble("yaw"), (float) y.getDouble("pitch"));
    }

    public void set(Location l) {
        spawn = l.clone();
        YamlConfiguration y = new YamlConfiguration();
        y.set("world", l.getWorld().getName());
        y.set("x", l.getX());
        y.set("y", l.getY());
        y.set("z", l.getZ());
        y.set("yaw", (double) l.getYaw());
        y.set("pitch", (double) l.getPitch());
        try {
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save spawn.yml: " + e.getMessage());
        }
    }

    /** The configured spawn, or the default world's spawn if none is set. */
    public Location get() {
        if (spawn != null) return spawn.clone();
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    public void teleport(Player p) {
        p.teleport(get());
        Util.msg(p, "&aTeleported to spawn.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (p.hasPlayedBefore()) return;
        if (!plugin.getConfig().getBoolean("spawn.teleport-new-players", true)) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) teleport(p);
        }, 1L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (e.isBedSpawn() || e.isAnchorSpawn()) return;
        e.setRespawnLocation(get());
    }
}
