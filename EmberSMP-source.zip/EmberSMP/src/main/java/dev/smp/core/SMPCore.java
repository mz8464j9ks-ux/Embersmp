package dev.smp.core;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class SMPCore extends JavaPlugin {
    private EconomyManager economy;
    private AuctionManager auctions;
    private OrderManager orders;
    private CrateManager crates;
    private GuiManager gui;
    private SpawnManager spawn;
    private RtpManager rtp;
    private SidebarManager sidebar;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "crates.yml").exists()) saveResource("crates.yml", false);

        economy = new EconomyManager(this);
        auctions = new AuctionManager(this);
        orders = new OrderManager(this);
        crates = new CrateManager(this);
        gui = new GuiManager(this);
        spawn = new SpawnManager(this);
        rtp = new RtpManager(this);
        sidebar = new SidebarManager(this);

        Commands handler = new Commands(this);
        for (String name : new String[]{"bal", "pay", "shards", "sell", "eco", "ah", "orders", "crate", "rtp", "spawn", "setspawn"}) {
            if (getCommand(name) != null) getCommand(name).setExecutor(handler);
        }

        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CrateListener(this), this);
        Bukkit.getPluginManager().registerEvents(spawn, this);
        Bukkit.getPluginManager().registerEvents(sidebar, this);

        sidebar.start();

        // Autosave every 5 minutes.
        long fiveMin = 5L * 60 * 20;
        Bukkit.getScheduler().runTaskTimer(this, this::saveAll, fiveMin, fiveMin);

        // Playtime shards.
        long minutes = Math.max(1, getConfig().getLong("shards.playtime-minutes", 10));
        long amount = getConfig().getLong("shards.playtime-amount", 1);
        if (amount > 0) {
            long period = minutes * 60 * 20;
            Bukkit.getScheduler().runTaskTimer(this, () -> {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    economy.addShards(p.getUniqueId(), amount);
                    Util.msg(p, "&b+" + amount + " " + shardsName() + " &7for playing.");
                }
            }, period, period);
        }
    }

    @Override
    public void onDisable() {
        saveAll();
    }

    private void saveAll() {
        if (economy != null) economy.save();
        if (auctions != null) auctions.save();
        if (orders != null) orders.save();
        if (crates != null) crates.save();
    }

    public EconomyManager economy() { return economy; }
    public AuctionManager auctions() { return auctions; }
    public OrderManager orders() { return orders; }
    public CrateManager crates() { return crates; }
    public GuiManager gui() { return gui; }
    public SpawnManager spawn() { return spawn; }
    public RtpManager rtp() { return rtp; }

    public String moneyName() { return getConfig().getString("names.money-name", "Money"); }
    public String shardsName() { return getConfig().getString("names.shards-name", "Shards"); }

    public String money(double amount) {
        return getConfig().getString("names.money-symbol", "$") + Util.num(amount);
    }
}
