package dev.smp.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;

public final class Util {
    private Util() {}

    /** Converts &-colour codes to a non-italic Component. */
    public static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    public static void msg(CommandSender to, String s) {
        to.sendMessage(c(s));
    }

    public static String num(double d) {
        return String.format(Locale.US, "%,.2f", d);
    }

    /** Gives an item; anything that doesn't fit is dropped at the player's feet. */
    public static void give(Player p, ItemStack item) {
        for (ItemStack left : p.getInventory().addItem(item).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
    }

    /** True for items with no custom name, lore, enchants, etc. */
    public static boolean plain(ItemStack i) {
        return i != null && !i.getType().isAir() && !i.hasItemMeta();
    }
}
