package dev.smp.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class RtpManager {
    /** Surface blocks you should never land on. */
    private static final Set<Material> UNSAFE = EnumSet.of(
            Material.CACTUS, Material.MAGMA_BLOCK, Material.FIRE, Material.SOUL_FIRE,
            Material.SWEET_BERRY_BUSH, Material.WITHER_ROSE, Material.POINTED_DRIPSTONE,
            Material.CAMPFIRE, Material.SOUL_CAMPFIRE);

    private final SMPCore plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> lastUse = new HashMap<>();

    public RtpManager(SMPCore plugin) {
        this.plugin = plugin;
    }

    public void rtp(Player p) {
        long cooldownMs = plugin.getConfig().getLong("rtp.cooldown-seconds", 60) * 1000L;
        long now = System.currentTimeMillis();
        Long last = lastUse.get(p.getUniqueId());
        if (last != null && now - last < cooldownMs) {
            long wait = (cooldownMs - (now - last) + 999) / 1000;
            Util.msg(p, "&cWait " + wait + "s before using /rtp again.");
            return;
        }

        World w = Bukkit.getWorld(plugin.getConfig().getString("rtp.world", "world"));
        if (w == null) w = Bukkit.getWorlds().get(0);

        int min = (int) Math.max(0, plugin.getConfig().getLong("rtp.min-radius", 500));
        int max = (int) Math.max(min + 1, plugin.getConfig().getLong("rtp.max-radius", 5000));
        int attempts = (int) Math.max(1, plugin.getConfig().getLong("rtp.max-attempts", 25));

        Util.msg(p, "&7Searching for a safe spot...");
        attempt(p, w, min, max, attempts);
    }

    private void attempt(Player p, World w, int min, int max, int triesLeft) {
        if (!p.isOnline()) return;
        if (triesLeft <= 0) {
            Util.msg(p, "&cCouldn't find a safe spot. Try again.");
            return;
        }

        int x = randomCoord(min, max);
        int z = randomCoord(min, max);

        // Load the chunk off the main thread, then check the spot back on it.
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!p.isOnline()) return;
                    Location safe = findSafe(w, x, z);
                    if (safe == null) {
                        attempt(p, w, min, max, triesLeft - 1);
                        return;
                    }
                    p.teleport(safe);
                    lastUse.put(p.getUniqueId(), System.currentTimeMillis());
                    Util.msg(p, "&aRandom teleport complete. &7(" + safe.getBlockX() + ", "
                            + safe.getBlockY() + ", " + safe.getBlockZ() + ")");
                })
        ).exceptionally(ex -> {
            plugin.getLogger().warning("RTP chunk load failed: " + ex.getMessage());
            Bukkit.getScheduler().runTask(plugin, () -> Util.msg(p, "&cRTP failed. Try again."));
            return null;
        });
    }

    private int randomCoord(int min, int max) {
        int v = min + random.nextInt(max - min);
        return random.nextBoolean() ? v : -v;
    }

    /** Returns a standable spot on top of the surface at x,z, or null if it's unsafe. */
    private Location findSafe(World w, int x, int z) {
        int y = w.getHighestBlockYAt(x, z);
        Block ground = w.getBlockAt(x, y, z);
        Material type = ground.getType();

        if (ground.isLiquid() || !type.isSolid() || UNSAFE.contains(type)) return null;

        Block feet = ground.getRelative(BlockFace.UP);
        Block head = feet.getRelative(BlockFace.UP);
        if (!feet.isPassable() || !head.isPassable()) return null;
        if (feet.isLiquid() || head.isLiquid()) return null;

        return new Location(w, x + 0.5, y + 1, z + 0.5);
    }
}
