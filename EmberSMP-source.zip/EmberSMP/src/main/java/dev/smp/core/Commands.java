package dev.smp.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

public class Commands implements CommandExecutor {
    private final SMPCore plugin;

    public Commands(SMPCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String label, @NotNull String[] a) {
        switch (cmd.getName().toLowerCase()) {
            case "bal" -> bal(s, a);
            case "pay" -> pay(s, a);
            case "shards" -> shards(s, a);
            case "sell" -> sell(s, a);
            case "eco" -> eco(s, a);
            case "ah" -> ah(s, a);
            case "orders" -> orders(s, a);
            case "crate" -> crate(s, a);
            case "rtp" -> rtp(s);
            case "spawn" -> spawn(s);
            case "setspawn" -> setspawn(s);
            default -> { return false; }
        }
        return true;
    }

    // ---------- spawn / rtp ----------

    private void rtp(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        plugin.rtp().rtp(p);
    }

    private void spawn(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        plugin.spawn().teleport(p);
    }

    private void setspawn(CommandSender s) {
        if (!admin(s)) return;
        Player p = player(s);
        if (p == null) return;
        plugin.spawn().set(p.getLocation());
        Util.msg(p, "&aSpawn set to your location.");
    }

    // ---------- helpers ----------

    private Player player(CommandSender s) {
        if (s instanceof Player p) return p;
        Util.msg(s, "&cOnly players can use this command.");
        return null;
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("smp.admin")) return true;
        Util.msg(s, "&cYou don't have permission.");
        return false;
    }

    private Double number(CommandSender s, String str) {
        try {
            double d = Double.parseDouble(str);
            if (Double.isNaN(d) || Double.isInfinite(d) || d <= 0) throw new NumberFormatException();
            return Math.round(d * 100.0) / 100.0;
        } catch (NumberFormatException ex) {
            Util.msg(s, "&cInvalid amount: " + str);
            return null;
        }
    }

    private Integer integer(CommandSender s, String str) {
        try {
            int i = Integer.parseInt(str);
            if (i <= 0) throw new NumberFormatException();
            return i;
        } catch (NumberFormatException ex) {
            Util.msg(s, "&cInvalid whole number: " + str);
            return null;
        }
    }

    // ---------- economy ----------

    private void bal(CommandSender s, String[] a) {
        Player target;
        if (a.length > 0) {
            target = Bukkit.getPlayerExact(a[0]);
            if (target == null) { Util.msg(s, "&cPlayer not online."); return; }
        } else {
            target = player(s);
            if (target == null) return;
        }
        Util.msg(s, "&e" + target.getName() + "&7: &a" + plugin.money(plugin.economy().getMoney(target.getUniqueId()))
                + " &7| &b" + plugin.economy().getShards(target.getUniqueId()) + " " + plugin.shardsName());
    }

    private void pay(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length < 2) { Util.msg(p, "&cUsage: /pay <player> <amount>"); return; }
        Player to = Bukkit.getPlayerExact(a[0]);
        if (to == null) { Util.msg(p, "&cPlayer not online."); return; }
        if (to.equals(p)) { Util.msg(p, "&cYou can't pay yourself."); return; }
        Double amt = number(p, a[1]);
        if (amt == null) return;
        if (!plugin.economy().takeMoney(p.getUniqueId(), amt)) { Util.msg(p, "&cNot enough " + plugin.moneyName() + "."); return; }
        plugin.economy().addMoney(to.getUniqueId(), amt);
        Util.msg(p, "&aPaid " + to.getName() + " " + plugin.money(amt) + ".");
        Util.msg(to, "&a" + p.getName() + " paid you " + plugin.money(amt) + ".");
    }

    private void shards(CommandSender s, String[] a) {
        if (a.length >= 3 && a[0].equalsIgnoreCase("give")) {
            if (!admin(s)) return;
            Player t = Bukkit.getPlayerExact(a[1]);
            Integer n = integer(s, a[2]);
            if (t == null) { Util.msg(s, "&cPlayer not online."); return; }
            if (n == null) return;
            plugin.economy().addShards(t.getUniqueId(), n);
            Util.msg(s, "&aGave " + n + " " + plugin.shardsName() + " to " + t.getName() + ".");
            return;
        }
        Player p = player(s);
        if (p == null) return;
        Util.msg(p, "&7You have &b" + plugin.economy().getShards(p.getUniqueId()) + " " + plugin.shardsName() + "&7.");
    }

    private void eco(CommandSender s, String[] a) {
        if (!admin(s)) return;
        if (a.length < 3) { Util.msg(s, "&cUsage: /eco <give|take> <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) { Util.msg(s, "&cPlayer not online."); return; }
        Double amt = number(s, a[2]);
        if (amt == null) return;
        if (a[0].equalsIgnoreCase("give")) {
            plugin.economy().addMoney(t.getUniqueId(), amt);
        } else if (a[0].equalsIgnoreCase("take")) {
            plugin.economy().takeMoney(t.getUniqueId(), amt);
        } else {
            Util.msg(s, "&cUsage: /eco <give|take> <player> <amount>");
            return;
        }
        Util.msg(s, "&aDone. " + t.getName() + " now has " + plugin.money(plugin.economy().getMoney(t.getUniqueId())) + ".");
    }

    private double priceOf(Material m) {
        return plugin.getConfig().isSet("sell-prices." + m.name())
                ? plugin.getConfig().getDouble("sell-prices." + m.name()) : -1;
    }

    private void sell(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        if (a.length < 1) { Util.msg(p, "&cUsage: /sell <hand|all>"); return; }

        double total = 0;
        int count = 0;
        if (a[0].equalsIgnoreCase("hand")) {
            ItemStack it = p.getInventory().getItemInMainHand();
            double price = Util.plain(it) ? priceOf(it.getType()) : -1;
            if (price < 0) { Util.msg(p, "&cThat item can't be sold."); return; }
            total = price * it.getAmount();
            count = it.getAmount();
            p.getInventory().setItemInMainHand(null);
        } else if (a[0].equalsIgnoreCase("all")) {
            ItemStack[] contents = p.getInventory().getStorageContents();
            for (int i = 0; i < contents.length; i++) {
                ItemStack it = contents[i];
                if (!Util.plain(it)) continue;
                double price = priceOf(it.getType());
                if (price < 0) continue;
                total += price * it.getAmount();
                count += it.getAmount();
                contents[i] = null;
            }
            p.getInventory().setStorageContents(contents);
        } else {
            Util.msg(p, "&cUsage: /sell <hand|all>");
            return;
        }

        if (count == 0) { Util.msg(p, "&cNothing sellable found."); return; }
        plugin.economy().addMoney(p.getUniqueId(), total);
        Util.msg(p, "&aSold " + count + " items for " + plugin.money(total) + ".");
    }

    // ---------- auction house ----------

    private void ah(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;

        if (a.length == 0) { plugin.gui().open(p, GuiHolder.Type.AH, 0); return; }
        if (a[0].equalsIgnoreCase("mine")) { plugin.gui().open(p, GuiHolder.Type.AH_MINE, 0); return; }
        if (!a[0].equalsIgnoreCase("sell") || a.length < 2) {
            Util.msg(p, "&cUsage: /ah, /ah mine, /ah sell <price>");
            return;
        }

        Double price = number(p, a[1]);
        if (price == null) return;
        if (price > plugin.getConfig().getDouble("auction.max-price", 1_000_000_000)) {
            Util.msg(p, "&cThat price is too high.");
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) { Util.msg(p, "&cHold the item you want to sell."); return; }
        if (plugin.auctions().bySeller(p.getUniqueId()).size() >= plugin.getConfig().getInt("auction.max-listings", 10)) {
            Util.msg(p, "&cYou've reached the listing limit.");
            return;
        }
        plugin.auctions().add(p.getUniqueId(), p.getName(), hand.clone(), price);
        p.getInventory().setItemInMainHand(null);
        Util.msg(p, "&aListed for " + plugin.money(price) + ". Manage with /ah mine.");
    }

    // ---------- player orders ----------

    private void orders(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;

        if (a.length == 0) { plugin.gui().open(p, GuiHolder.Type.ORDERS, 0); return; }

        switch (a[0].toLowerCase()) {
            case "mine" -> plugin.gui().open(p, GuiHolder.Type.ORDERS_MINE, 0);
            case "collect" -> {
                Map<Material, Integer> items = plugin.orders().takePending(p.getUniqueId());
                if (items.isEmpty()) { Util.msg(p, "&cNothing to collect."); return; }
                items.forEach((mat, n) -> {
                    int left = n;
                    while (left > 0) {
                        int stack = Math.min(left, mat.getMaxStackSize());
                        Util.give(p, new ItemStack(mat, stack));
                        left -= stack;
                    }
                });
                Util.msg(p, "&aCollected your order items.");
            }
            case "create" -> createOrder(p, a);
            default -> Util.msg(p, "&cUsage: /orders, /orders mine, /orders collect, /orders create <item> <amount> <priceEach>");
        }
    }

    private void createOrder(Player p, String[] a) {
        if (a.length < 4) { Util.msg(p, "&cUsage: /orders create <item> <amount> <priceEach>"); return; }
        Material mat = Material.matchMaterial(a[1]);
        if (mat == null || !mat.isItem() || mat.isAir()) { Util.msg(p, "&cUnknown item: " + a[1]); return; }
        Integer amount = integer(p, a[2]);
        Double each = number(p, a[3]);
        if (amount == null || each == null) return;

        if (amount > plugin.getConfig().getInt("orders.max-amount", 2304)) { Util.msg(p, "&cAmount too large."); return; }
        if (each > plugin.getConfig().getDouble("orders.max-price-each", 1_000_000)) { Util.msg(p, "&cPrice too high."); return; }
        if (plugin.orders().byBuyer(p.getUniqueId()).size() >= plugin.getConfig().getInt("orders.max-orders-per-player", 5)) {
            Util.msg(p, "&cYou've reached the order limit.");
            return;
        }

        double cost = amount * each;
        if (!plugin.economy().takeMoney(p.getUniqueId(), cost)) {
            Util.msg(p, "&cYou need " + plugin.money(cost) + " to place this order.");
            return;
        }
        plugin.orders().create(p.getUniqueId(), p.getName(), mat, amount, each);
        Util.msg(p, "&aOrder placed for " + amount + "x " + GuiListener.pretty(mat) + ". " + plugin.money(cost)
                + " held until filled or cancelled.");
    }

    // ---------- crates ----------

    private void crate(CommandSender s, String[] a) {
        if (!admin(s)) return;
        if (a.length == 0) { Util.msg(s, "&cUsage: /crate <give|set|remove|list|reload>"); return; }

        switch (a[0].toLowerCase()) {
            case "list" -> Util.msg(s, "&7Crates: &f" + String.join(", ", plugin.crates().ids()));
            case "reload" -> {
                plugin.reloadConfig();
                plugin.crates().load();
                Util.msg(s, "&aReloaded.");
            }
            case "give" -> {
                if (a.length < 3) { Util.msg(s, "&cUsage: /crate give <player> <crate> [amount]"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                CrateManager.Crate c = plugin.crates().get(a[2]);
                if (t == null) { Util.msg(s, "&cPlayer not online."); return; }
                if (c == null) { Util.msg(s, "&cUnknown crate."); return; }
                Integer n = a.length > 3 ? integer(s, a[3]) : Integer.valueOf(1);
                if (n == null) return;
                Util.give(t, plugin.crates().createKey(c, n));
                Util.msg(s, "&aGave " + n + " key(s) to " + t.getName() + ".");
            }
            case "set", "remove" -> {
                Player p = player(s);
                if (p == null) return;
                Block b = p.getTargetBlockExact(5);
                if (b == null) { Util.msg(p, "&cLook at a block within 5 blocks."); return; }
                if (a[0].equalsIgnoreCase("remove")) {
                    Util.msg(p, plugin.crates().removeCrate(b) ? "&aCrate removed." : "&cThat block isn't a crate.");
                    return;
                }
                CrateManager.Crate c = a.length > 1 ? plugin.crates().get(a[1]) : null;
                if (c == null) { Util.msg(p, "&cUsage: /crate set <crate>"); return; }
                plugin.crates().setCrate(b, c);
                Util.msg(p, "&aThat block is now a " + c.display() + "&a.");
            }
            default -> Util.msg(s, "&cUsage: /crate <give|set|remove|list|reload>");
        }
    }
}
