package dev.smp.core;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class GuiManager {
    private static final int PAGE_SIZE = 45;
    private final SMPCore plugin;

    public GuiManager(SMPCore plugin) {
        this.plugin = plugin;
    }

    public void open(Player p, GuiHolder.Type type, int page) {
        List<UUID> ids = new ArrayList<>();
        List<ItemStack> icons = new ArrayList<>();
        String title;

        switch (type) {
            case AH -> {
                title = "Auction House";
                for (AuctionManager.Listing l : plugin.auctions().all()) {
                    ids.add(l.id());
                    icons.add(withLore(l.item().clone(),
                            "&7Price: &a" + plugin.money(l.price()),
                            "&7Seller: &f" + l.sellerName(),
                            "",
                            "&eClick to buy"));
                }
            }
            case AH_MINE -> {
                title = "Your Listings";
                for (AuctionManager.Listing l : plugin.auctions().bySeller(p.getUniqueId())) {
                    ids.add(l.id());
                    icons.add(withLore(l.item().clone(),
                            "&7Price: &a" + plugin.money(l.price()),
                            "",
                            "&cClick to cancel and get item back"));
                }
            }
            case ORDERS -> {
                title = "Player Orders";
                for (OrderManager.Order o : plugin.orders().all()) {
                    ids.add(o.id);
                    icons.add(withLore(new ItemStack(o.material),
                            "&7Buyer: &f" + o.buyerName,
                            "&7Wanted: &f" + o.remaining,
                            "&7Pays: &a" + plugin.money(o.priceEach) + " &7each",
                            "",
                            "&eClick to sell items from your inventory"));
                }
            }
            default -> {
                title = "Your Orders";
                for (OrderManager.Order o : plugin.orders().byBuyer(p.getUniqueId())) {
                    ids.add(o.id);
                    icons.add(withLore(new ItemStack(o.material),
                            "&7Remaining: &f" + o.remaining,
                            "&7Price each: &a" + plugin.money(o.priceEach),
                            "",
                            "&cClick to cancel and refund"));
                }
            }
        }

        int maxPage = Math.max(0, (icons.size() - 1) / PAGE_SIZE);
        int pg = Math.max(0, Math.min(page, maxPage));

        GuiHolder holder = new GuiHolder(type, pg);
        Inventory inv = Bukkit.createInventory(holder, 54, Util.c(title + " &8(" + (pg + 1) + "/" + (maxPage + 1) + ")"));
        holder.setInventory(inv);

        int from = pg * PAGE_SIZE;
        for (int i = from; i < Math.min(icons.size(), from + PAGE_SIZE); i++) {
            inv.setItem(i - from, icons.get(i));
            holder.ids.add(ids.get(i));
        }

        if (pg > 0) inv.setItem(45, named(Material.ARROW, "&ePrevious page"));
        if (pg < maxPage) inv.setItem(53, named(Material.ARROW, "&eNext page"));
        inv.setItem(49, named(Material.PAPER, "&7Balance: &a" + plugin.money(plugin.economy().getMoney(p.getUniqueId()))));

        p.openInventory(inv);
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Util.c(name));
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack withLore(ItemStack it, String... lines) {
        ItemMeta meta = it.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String s : lines) lore.add(Util.c(s));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }
}
