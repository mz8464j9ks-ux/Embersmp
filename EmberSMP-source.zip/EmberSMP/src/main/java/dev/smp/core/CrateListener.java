package dev.smp.core;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class CrateListener implements Listener {
    private final SMPCore plugin;

    public CrateListener(SMPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        CrateManager.Crate crate = plugin.crates().crateAt(e.getClickedBlock());
        if (crate == null) return;

        e.setCancelled(true);
        Player p = e.getPlayer();

        if (e.getAction() == Action.LEFT_CLICK_BLOCK) {
            plugin.crates().preview(p, crate);
            return;
        }
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!plugin.crates().isKeyFor(hand, crate)) {
            Util.msg(p, "&cYou need a " + crate.display() + " &cKey in your hand.");
            return;
        }
        hand.setAmount(hand.getAmount() - 1);
        plugin.crates().open(p, crate);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (plugin.crates().crateAt(e.getBlock()) != null) {
            e.setCancelled(true);
            Util.msg(e.getPlayer(), "&cThis is a crate. Admins: use /crate remove while looking at it.");
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (plugin.orders().hasPending(e.getPlayer().getUniqueId())) {
            Util.msg(e.getPlayer(), "&aYou have order items waiting. Use &e/orders collect&a.");
        }
    }
}
